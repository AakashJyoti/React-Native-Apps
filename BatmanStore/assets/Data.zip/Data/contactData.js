export const contactData = [
    {
      image: "https://img.icons8.com/ios/50/000000/whatsapp--v1.png",
      text: "+91-8287880685",
    },
    {
      image: "https://img.icons8.com/ios/100/000000/mail.png",
      text: "store@info.in",
    },
    {
      image: "https://img.icons8.com/ios/100/000000/ringing-phone.png",
      text: "+91-8700963181, +91-8287880685",
    },
    {
      image: "https://img.icons8.com/ios/100/000000/address--v1.png",
      text: "Shop No. 12, Khasra No. 389/219, Paryavaran Complex, New Delhi-110030",
    },
    {
      image: "https://img.icons8.com/ios/100/000000/facebook--v1.png",
      text: "Shivayattachakkiandoikolhu",
    },
    {
      image: "https://img.icons8.com/ios/50/000000/instagram-new--v1.png",
      text: "Shivayattachakkiandoikolhu",
    },
  ];
  