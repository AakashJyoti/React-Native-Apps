export const localRestaurants = [
  {
    name: "Premium MP Sharbati Atta",
    image_url:
      "https://img00.deviantart.net/c930/i/2017/296/d/7/spikes__wheat__flour_on_a_transparent_background__by_prussiaart-dbrhdwh.png",
    categories: ["Atta", "Premium Wheat"],
    price: "42 ₹/kg",
    reviews: 124,
    rating: 4.5,
    prices: [
      { price: "210", weight: "5kg" },
      { price: "420", weight: "10kg" },
    ],
  },
  {
    name: "MP Sharbati Atta",
    image_url:
      "https://image.shutterstock.com/image-photo/flour-wheat-grain-260nw-569095345.jpg",
    categories: ["Atta", "Wheet"],
    price: "40 ₹/kg",
    reviews: 144,
    rating: 3.7,
    prices: [
      { price: "200", weight: "5kg" },
      { price: "400", weight: "10kg" },
    ],
  },
  {
    name: "Desi MP Sharbati Atta",
    image_url:
      "https://5.imimg.com/data5/TV/IP/GLADMIN-30212742/wheat-flour-500x500.png",
    categories: ["Atta", "Desi Wheat"],
    price: "37 ₹/kg",
    reviews: 14,
    rating: 4.7,
    prices: [
      { price: "185", weight: "5kg" },
      { price: "370", weight: "10kg" },
    ],
  },
  {
    name: "Multi Grain Atta",
    image_url:
      "https://static01.nyt.com/images/2020/03/17/well/askwell-wholegrains/askwell-wholegrains-articleLarge.jpg?quality=75&auto=webp&disable=upscale",
    categories: ["Atta", "Multi Grain"],
    price: "95 ₹/kg",
    reviews: 14,
    rating: 4.2,
    prices: [
      { price: "50", weight: "500g" },
      { price: "95", weight: "1kg" },
    ],
  },

  {
    name: "Mustard Oil",
    image_url:
      "https://5.imimg.com/data5/KB/GO/MY-55972666/mustard-oil-28sarso-ka-teel-29-500x500.jpg",
    categories: ["Oil", "Mustard"],
    price: "195 ₹/L",
    reviews: 14,
    rating: 4.2,
    prices: [
      { price: "100", weight: "500ml" },
      { price: "195", weight: "1L" },
    ],
  },
  {
    name: "Badam Rogan Oil",
    image_url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRbNZkhS3Ve991x3BPziwMLhq_J-3rHCJ4gQg&usqp=CAU",
    categories: ["Oil", "Badam Rogan"],
    price: "2000 ₹/L",
    reviews: 14,
    rating: 4.2,
    prices: [
      { price: "2000", weight: "1L" },
      { price: "1000", weight: "500ml" },
      { price: "500", weight: "250ml" },
      { price: "200", weight: "100ml" },
    ],
  },
  {
    name: "Coconut Oil",
    image_url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7Xiwy-5Gt14VwUnNPhYSG8WoqoV1d25lhpMiTuD1osQBNOC83o3FPyfCYOzn1_oUkilQ&usqp=CAU",
    categories: ["Oil", "Coconut"],
    price: "520 ₹/L",
    reviews: 14,
    rating: 4.2,
    prices: [
      { price: "520", weight: "1L" },
      { price: "260", weight: "500ml" },
      { price: "130", weight: "250ml" },
      { price: "55", weight: "100ml" },
    ],
  },
  {
    name: "Seasem/Til Oil",
    image_url:
      "https://d2n7tchuu1wmsv.cloudfront.net/uploads/15191/products/1593597889_tilkatel.png",
    categories: ["Oil", "Til"],
    price: "420 ₹/L",
    reviews: 14,
    rating: 4.2,
    prices: [
      { price: "420", weight: "1L" },
      { price: "210", weight: "500ml" },
      { price: "110", weight: "250ml" },
      { price: "45", weight: "100ml" },
    ],
  },
  {
    name: "Moongfali Oil",
    image_url:
      "https://images.newindianexpress.com/uploads/user/imagelibrary/2021/9/15/w900X450/The_gains.jpg?w=400&dpr=2.6",
    categories: ["OIL", "Mungfali"],
    price: "360 ₹/L",
    reviews: 14,
    rating: 4.2,
    prices: [
      { price: "360", weight: "1L" },
      { price: "180", weight: "500ml" },
      { price: "90", weight: "250ml" },
      { price: "40", weight: "100ml" },
    ],
  },
  {
    name: "Besan",
    image_url:
      "https://thumbs.dreamstime.com/b/chana-daal-besan-indian-food-chana-daal-besan-indian-food-120123251.jpg",
    categories: ["Atta", "Besan"],
    price: "48 ₹/kg",
    reviews: 14,
    rating: 4.2,
    prices: [
      { price: "240", weight: "5kg" },
      { price: "480", weight: "10kg" },
    ],
  },
];
