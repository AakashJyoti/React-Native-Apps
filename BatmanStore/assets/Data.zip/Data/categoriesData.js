export const items = [
    {
        image: require('../Images/wheat.png'),
        text: 'Wheat',
    },
    {
        image: require('../Images/corn.png'),
        text: 'Pop Corn',
    },
    {
        image: require('../Images/rice.png'),
        text: 'Rice',
    },
    {
        image: require('../Images/spices.png'),
        text: 'Spices',
    },
    {
        image: require('../Images/pulses.png'),
        text: 'Pulses',
    },
    {
        image: require('../Images/mustardoil.png'),
        text: 'Mustard Oil',
    },
    {
        image: require('../Images/flours.png'),
        text: 'Flours',
    },
];